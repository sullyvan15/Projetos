
package Main;
/**
 *
 * @author Sullyvan
 */
public class Main {
    public static void main(String[] args) {
        
            int x = 0;
        
            Municipio municipio = new Municipio();
                municipio.hashMap(x);
    }
}