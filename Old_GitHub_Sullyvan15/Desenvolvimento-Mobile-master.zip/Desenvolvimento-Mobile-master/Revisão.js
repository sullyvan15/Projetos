//01) criar dois vetores de numeros usando uma arrow function.
const arr = {
	x: [limite],
	y: [limite],
};
console.log (x);

//Para tal fazer a funcao recebe como parametro a (quantidade)
//quantidade: quantos numeros devem ser gerados
item(arr) => {
	let limite =10;
	x = Math.floor(Math.random () * limite);
	y = Math.floor(Math.random () * limite);
};

//e retorna dois vetores com a mesma quantidade de pares e impares: (vetor de vetor)
return x.map, y.map;