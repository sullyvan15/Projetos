var input = require('fs').readFileSync('/dev/stdin', 'utf8');
var lines = input.split('\n');

console.log('       A');
console.log('      B B');
console.log('     C   C');
console.log('    D     D');
console.log('   E       E');
console.log('    D     D');
console.log('     C   C');
console.log('      B B');
console.log('       A');