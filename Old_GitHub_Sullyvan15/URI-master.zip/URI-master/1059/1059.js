for(var x = 2; x <= 100; x = x+2)
    console.log(x);
