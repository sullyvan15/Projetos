﻿# UriOnlineJudge
Repositório para solução dos problemas do UriOnlineJudge em JavaScript.

Utilizando o Node para os casos de teste:

Abra o CMD
Em seguida especifice o diretório em que está seu arquivo JS
Após isso execute o comando: node 'nomedoarquivo'.js


No meu exemplo, meu arquivo está no desktop e se chama uri.js

Abra o CMD;
CD Desktop;
node uri.js;
deve ser armazenado os inputs dentro de um txt (como especificado pelo uri)
no meu caso armazeno no test.txt.
