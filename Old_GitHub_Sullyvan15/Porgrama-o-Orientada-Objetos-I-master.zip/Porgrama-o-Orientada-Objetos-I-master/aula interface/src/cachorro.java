
public class cachorro extends animal implements Pet {

    @Override
    public void coçarBarriga() {
        System.out.println("Cachorro: coçarBarriga");
        
    }

   



}
        
    

