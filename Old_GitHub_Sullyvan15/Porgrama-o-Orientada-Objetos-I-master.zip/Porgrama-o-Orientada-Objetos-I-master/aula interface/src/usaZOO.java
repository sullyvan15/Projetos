
public class usaZOO {
    public static  void main(String[]args){
        cachorro ca = new cachorro();
         gato ga = new gato();
         leão le = new leão();
         ca.nascer();
         ga.nascer();
         le.nascer();
    }
            
}
