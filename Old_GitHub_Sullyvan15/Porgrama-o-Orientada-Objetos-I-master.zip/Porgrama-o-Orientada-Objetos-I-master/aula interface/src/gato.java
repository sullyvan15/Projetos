/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author alunodev08
 */
public class gato extends animal implements Pet{

    @Override
    public void coçarBarriga() {
          System.out.println("Gato: coçarBarriga");
    }
    
}
