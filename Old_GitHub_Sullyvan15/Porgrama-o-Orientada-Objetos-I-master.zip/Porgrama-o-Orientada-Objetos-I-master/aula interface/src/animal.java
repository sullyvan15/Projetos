
public abstract class animal {
    protected String nome;
    
    public void nascer(){
    System.out.println("Animal: nascer()");
}

 // public abstract void coçarBarriga();
    
}


