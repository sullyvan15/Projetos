/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidade;


public class Humbio extends Cursos{	
	//CONTRUTOR DO OBJETO
	//*******************	
	public Humbio(String descricao, int quantidade, float valor) {
		super(descricao, quantidade, valor);
	}
}