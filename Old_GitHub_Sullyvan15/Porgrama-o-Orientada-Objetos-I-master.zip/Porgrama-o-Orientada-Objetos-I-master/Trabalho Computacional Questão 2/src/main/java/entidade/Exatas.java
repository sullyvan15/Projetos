package entidade;
public class Exatas extends Cursos{	
	//CONTRUTOR DO OBJETO
	//*******************	
	public Exatas(String descricao, int quantidade, float valor) {
		super(descricao, quantidade, valor);
	}
}