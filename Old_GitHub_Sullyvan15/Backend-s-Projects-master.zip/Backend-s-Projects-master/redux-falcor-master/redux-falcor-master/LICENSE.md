Visit https://supportedsource.org/projects/redux-falcor to get a license.

Depending on your company's size, the license may be free. It is free for individuals.
