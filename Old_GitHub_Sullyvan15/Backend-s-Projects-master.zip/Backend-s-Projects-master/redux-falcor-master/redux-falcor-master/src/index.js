export { default as reducer } from './components/duck';
export { default as FalcorProvider } from './components/FalcorProvider';
export { default as reduxFalcor } from './components/reduxFalcor';
