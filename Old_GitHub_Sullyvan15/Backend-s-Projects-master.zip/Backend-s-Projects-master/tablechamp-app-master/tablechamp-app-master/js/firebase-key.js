var cs = { 
  "apiKey": '', 
  "authDomain": '', 
  "databaseURL": '' 
};