//replace <username> and <password> with your mongoDB atlas accounts info
module.exports = "mongodb://heroku_8bd94qrf:irstf0rv1ds970eebtislm0apf@ds029638.mlab.com:29638/heroku_8bd94qrf"

