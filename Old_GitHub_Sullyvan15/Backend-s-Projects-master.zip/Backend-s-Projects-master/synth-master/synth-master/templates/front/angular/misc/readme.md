Place any static files that you want your server to make available from the
root path here.

This can include a robots.txt (which by default prevents Google from indexing
the app), or a favicon.ico file.

For example, the included robots.txt will be served up from '/robots.txt'.
