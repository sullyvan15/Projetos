Place any image files you'd like served up here.

If you place a file called 'boat.jpeg', it will be served up from your web app
at '/images/boat.jpeg'.
