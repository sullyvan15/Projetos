/* Init and return synth app */
module.exports = require('synth')();
