require('some-non-existent-module');
