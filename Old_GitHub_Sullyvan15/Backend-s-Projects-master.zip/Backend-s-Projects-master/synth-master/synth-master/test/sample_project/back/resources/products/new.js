exports.post = function () {
  // create new product
};
