function main () {
  // A comment
  return true;
}
