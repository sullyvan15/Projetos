const Ticket = require('./ticket.model.js');

module.exports = {
  Ticket,
};
