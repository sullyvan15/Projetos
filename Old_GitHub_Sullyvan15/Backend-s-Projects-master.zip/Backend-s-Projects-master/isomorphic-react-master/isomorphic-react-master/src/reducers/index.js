/**
 * Exports of this module is an object where the keys are the names of the properties the reducers operate on,
 * and the value is the actual reducer
 */
export { questions } from './questions';