#include <stdio.h>
#include <stdlib.h>

int main()
 {
 	int a = 5, b, c ,d;

 	a--;
 	b = a % 3 *5;
 	c = (a + b) % 2;
 	d = c++;
 	d = ++c;
 	printf("Valor de a: %i/n  Valor de b:%i/n Valor de c: %i/n Valor de d: %i/n", a,b,c,d );
 	#include <stdio.h>
#include <stdlib.h>

int main()
 {
 	int a = 5, b, c ,d;

 	a--;
 	b = a % 3 *5;
 	c = (a + b) % 2;
 	d = c++;
 	d = ++c;
 	printf("Valor de a: %i/n  Valor de b:%i/n Valor de c: %i/n Valor de d: %i/n", a,b,c,d );


}
return 0;



}

