// This is the file that contains all the question, answer and point value data.

var json = [{
	// Example Object
	"question": "Question 1 goes here",
	"answers": ["Answer 1", "Answer 2", "Answer 3", "Answer 4"],
	"points": [21, 17, 16, 16, 8, 8, 7, 7]
},{
	// Example Object
	"question": "Question 2 goes here",
	"answers": ["Answer 1", "Answer 2", "Answer 3", "Answer 4"],
	"points": [21, 17, 16, 16, 8, 8, 7, 7]
}
	//...Append additional questions here
];
