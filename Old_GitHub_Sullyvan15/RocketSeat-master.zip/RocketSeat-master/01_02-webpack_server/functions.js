export const idade = 23;
export default class Usuario {
    static info() {
        console.log('Apenas teste');
    }
}