// Exercicio 06

//Converta o seguinte trecho de código utilizando Template Literals:

const usuario = 'Diego'; 
const idade = 23; 
console.log('O usuário ' + usuario + ' possui ' + idade + ' anos');

/* >>>>> */ console.log(`O usuario ${usuario} possui ${idade} anos`)